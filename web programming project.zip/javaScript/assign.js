/**Control .tab-links class to show tab-contents in Resume Page.
   function is designed to switch between different tabs by toggling 
   the "active-link" and "active-tab" classes on the relevant elements.*/ 
var tablinks = document.getElementsByClassName("tab-links");
var tabcontents = document.getElementsByClassName("tab-contents");

function opentab(tabname) {
    for(var tablink of tablinks){
        tablink.classList.remove("active-link");
    }
    for(var tabcontent of tabcontents){
        tabcontent.classList.remove("active-tab");
    }
    event.currentTarget.classList.add("active-link");
    document.getElementById(tabname).classList.add("active-tab");
}

// Sidemenu control for small screen to show navbar in sidemenu. 
var sidemenu = document.getElementById("sidemenu");
function openmenu() {
  sidemenu.style.right = "0";
}
// x control for small screen to close nav bar in sidemenu. 
function closemenu() {
  sidemenu.style.right = "-200px";
}

// Add an event listener to the document object that listens for the 'DOMContentLoaded' event
// which fires when the initial HTML document has been completely loaded and parsed. 
document.addEventListener("DOMContentLoaded", filterSelection("all"));


filterSelection("all")

// Search function for course name based on user input.
function searchCourses() {
// Get the user input and convert to lowercase
const input = document.getElementById("search").value.toLowerCase();
// Get all courses in the div of "courses"
const courses = document.querySelectorAll("#courses .course"); 

// for Loop go through each course
for (let i = 0; i < courses.length; i++) {
    const name = courses[i].querySelector(".course-name").textContent.toLowerCase(); // Get the course name and convert to lowercase
    const code = courses[i].querySelectorAll("p")[1].textContent.toLowerCase(); // Get the course code and convert to lowercase
    
    if (name.includes(input) || code.includes(input)) {
      courseAddClass(courses[i], "show");
    } else {
      courseRemoveClass(courses[i], "show");
    }
}
}

// filter function for level
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("filterDiv");
  var filterbtns = document.getElementsByClassName("btnlevel1");
  for(i=0;i<filterbtns.length;i++){
    courseRemoveClass(filterbtns[i],"active");
  }

  if (c == "all") {
    courseRemoveClass(x[i], "show");
    courseAddClass(filterbtns[0],"active")
    c = "";
  }else if(c=="level1"){
    courseAddClass(filterbtns[1],"active")
  }else{
    courseAddClass(filterbtns[2],"active")
  }

// Add the "show" class (display:block) to the filtered elements, and remove the "show" class from the elements that are not selected
  for (i = 0; i < x.length; i++) {
    courseRemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) courseAddClass(x[i], "show");
  }
}

function orderSelection(o) {
  var x, i;
  var studylist = document.getElementsByClassName("study-list")[0];
  var filterbtns = document.getElementsByClassName("btnlevel2");
  x = document.getElementsByClassName("filterDiv");
  for(i=0;i<filterbtns.length;i++){
    courseRemoveClass(filterbtns[i],"active");
  }

  if (o == "1") {
    courseAddClass(filterbtns[0],"active")
  }else{
    courseAddClass(filterbtns[1],"active")
  }

  x = orderList(studylist,x,o);
}

function orderList(course, dataList, order){
  var sortedList = Array.from(dataList).sort((a, b) => {
    var aText = a.id;
    var bText = b.id;
    if(order == "2"){ //hight to low
      if (aText < bText) return 1;
      if (aText > bText) return -1;
      return 0;
    }else{
      if (aText < bText) return -1;
      if (aText > bText) return 1;
      return 0;
    }
  });
  while (course.firstChild) {
    course.removeChild(course.firstChild);
  }
  sortedList.forEach((item) => {
    course.appendChild(item);
  });
  return dataList;
};

// Show filtered elements
function courseAddClass(element, name) {
  var i, arr1, arr2;
  try{
      arr1 = element.className.split(" ");
      arr2 = name.split(" ");
      for (i = 0; i < arr2.length; i++) {
        if (arr1.indexOf(arr2[i]) == -1) {
          element.className += " " + arr2[i];
        }
      }
  }catch(e){

  }
}

// Hide elements that are not selected
function courseRemoveClass(element, name) {
  var i, arr1, arr2;
  try{
    arr1 = element.className.split(" ");
    arr2 = name.split(" ");
    for (i = 0; i < arr2.length; i++) {
      while (arr1.indexOf(arr2[i]) > -1) {
        arr1.splice(arr1.indexOf(arr2[i]), 1);
      }
    }
    element.className = arr1.join(" ");
  }catch(e){
      
  }
}

// Add active class to the current control button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
if(btnContainer != null){
  var btns = btnContainer.getElementsByClassName("btn");
  for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("active");
      current[0].className = current[0].className.replace(" active", "");
      this.className += " active";
    });
  }
}


//Add submit function to contact page
const url = 'https://script.google.com/macros/s/AKfycbxktZLdwGuCHn4R1zqz80WPWNvvacFfdAWAlFwGGPXhzwrVLBUtxtPWbQwFDECyvACvGQ/exec'
const form = document.forms['submit-to-google-sheet']

form.addEventListener('submit', e => {
    e.preventDefault()
    fetch(url, { method: 'POST', body: new FormData(form)})
        .then(response => {
        msg.innerHTML = "Message has been sent successfully!"
        setTimeout(function(){
            msg.innerHTML = ""
        }, 5000)
        form.reset()
        })
        .catch(error => console.error('Error!', error.message))
    })
